---
name: Stitch
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#4d4635'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#7f7663'
  outline-variant: '#d0c5af'
  surface-tint: '#735c00'
  primary: '#735c00'
  on-primary: '#ffffff'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#e9c349'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2dfde'
  on-secondary-container: '#636262'
  tertiary: '#5f5e5a'
  on-tertiary: '#ffffff'
  tertiary-container: '#b5b3ae'
  on-tertiary-container: '#464541'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e5e2dc'
  tertiary-fixed-dim: '#c9c6c1'
  on-tertiary-fixed: '#1c1c18'
  on-tertiary-fixed-variant: '#474743'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e3e2e2'
typography:
  display-lg:
    fontFamily: Vazirmatn
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 48px
  display-lg-mobile:
    fontFamily: Vazirmatn
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Vazirmatn
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Vazirmatn
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 28px
  body-sm:
    fontFamily: Vazirmatn
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Vazirmatn
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.02em
  price-tag:
    fontFamily: Vazirmatn
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 20px
  gutter: 16px
  section-gap: 40px
  stack-sm: 4px
  stack-md: 12px
---

## Brand & Style
The design system is built on a foundation of **Modern Professionalism** with a **Tactile Luxury** edge. It caters to the beauty and grooming industry by balancing clinical precision (for booking and scheduling) with warm, inviting aesthetics. 

The visual direction is a blend of **Minimalism** and **Soft Neomorphism**. It utilizes ample whitespace, refined typography, and subtle depth to evoke a sense of high-end service and cleanliness. The interface must feel calm and organized, reducing the cognitive load during the appointment selection process. All interactions follow a Right-to-Left (RTL) flow, ensuring a natural reading pattern for Persian speakers.

## Colors
The palette is anchored by **Rose Gold (#D4AF37)**, used strategically for primary actions and brand accents to convey luxury. 

- **Primary:** Rose Gold is reserved for "Book Now" buttons, active states, and brand-critical iconography.
- **Secondary:** A deep Charcoal (#1A1A1A) provides strong contrast for headings and primary text.
- **Surface/Neutral:** The background uses a very soft Cream (#F9F6F0) instead of pure white to maintain a "warm" professional feel. Greyscale tones are used for borders (#E0E0E0) and secondary text (#717171).
- **Status:** Functional colors are slightly muted to remain harmonious with the warm brand palette while ensuring clear communication of appointment states (Success, Canceled, Pending).

## Typography
This design system utilizes **Vazirmatn** for all levels to ensure perfect Persian legibility and native support for Persian numerals. 

- **Persian Numerals:** All price points, ratings, and time slots must use native Persian glyphs (e.g., ۱ ۲ ۳).
- **Hierarchical Contrast:** Large, bold headings are used for Salon names and section titles. Body text maintains a generous line height (1.6x - 1.7x) to accommodate the taller x-height of Persian script.
- **Alignment:** All text is right-aligned by default. Tracking (letter-spacing) is kept at 0 for Persian script, as spacing can break the cursive nature of the characters.

## Layout & Spacing
The layout uses a **Fluid Grid** system with specific logic for RTL rendering.

- **Desktop:** 12-column grid, 1200px max-width, 24px gutters.
- **Mobile:** 4-column grid, 16px margins.
- **RTL Logic:** Layouts flip horizontally. The "Next" button in steppers or carousels sits on the left, and the "Back" button sits on the right.
- **Spacing Rhythm:** Based on an 8px scale. Use `stack-md` (12px) for spacing between elements within a card and `section-gap` (40px) to separate distinct content blocks like "Services" and "Reviews."

## Elevation & Depth
To achieve the "Professional & Clean" look, this design system avoids heavy shadows. Instead, it uses **Tonal Layers** and **Soft Ambient Occlusion**.

- **Level 0 (Background):** #F9F6F0 (Cream).
- **Level 1 (Cards/Surface):** Pure White (#FFFFFF) with a 1px border of #E0E0E0. This creates a "lifted" effect without heavy shadows.
- **Level 2 (Active/Hover):** A very soft, diffused shadow (0px 4px 20px rgba(0, 0, 0, 0.05)) used for selected service cards or active modals.
- **Glassmorphism:** Used sparingly for the "Mobile Bottom Navigation" and "Fixed Headers." A backdrop blur of 10px with 80% opacity white creates a modern, premium feel.

## Shapes
The shape language is **Rounded**, conveying friendliness and beauty.

- **Standard Elements:** 8px (0.5rem) radius for input fields, service cards, and small buttons.
- **Container Elements:** 16px (1rem) radius for large cards (Salon results) and modals.
- **Pill Shapes:** Used exclusively for "Status Badges" and "Time Slots" to make them feel like interactable "objects."
- **Media:** Barbershop and stylist photos should use a `rounded-lg` (16px) corner to maintain the soft aesthetic.

## Components

### Barbershop Result Card
- **Structure:** Image (Top/Right), Content (Bottom/Left).
- **Details:** Include a "Verified" badge (Rose Gold icon) next to the name. Rating should be displayed as a star icon followed by the Persian numeral.
- **CTA:** The price range and "Next Slot" should be grouped together to create urgency.

### Booking Calendar
- **Interaction:** Horizontal scroll for dates. Selected date uses a Primary Color background with white text.
- **Time Slots:** Displayed as a grid of pill-shaped buttons. Unavailable slots are shown in a light grey with a strike-through or 30% opacity.

### Buttons & Inputs
- **Primary Button:** Rose Gold background, white text, bold Vazirmatn. 
- **Input Fields:** Bottom-border only or light-grey outline. Label should float to the right (RTL).
- **OTP Input:** 4-6 distinct square boxes with a 2px border that turns Rose Gold on focus.

### Mobile Bottom Navigation
- **Style:** Fixed at the bottom with a backdrop-blur. 
- **Items:** Home, Appointments, Favorites, Profile. Active item uses the Primary Color for both icon and label.

### Status Badges
- **Success:** Soft green background with dark green text.
- **Canceled/Error:** Soft red background with dark red text.
- **Pending:** Soft yellow background with dark gold text.